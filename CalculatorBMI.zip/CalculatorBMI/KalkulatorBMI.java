import javax.swing.*;

public class KalkulatorBMI {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Form());
    }
}

